import Vues.User.FrmAcceuil;


import java.sql.SQLException;

public class Main
{
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        FrmAcceuil frm = new FrmAcceuil();
        frm.setVisible(true);
    }
}

